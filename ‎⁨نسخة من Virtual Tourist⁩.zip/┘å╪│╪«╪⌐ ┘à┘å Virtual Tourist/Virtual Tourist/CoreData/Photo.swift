//
//  Photo.swift
//  Virtual Tourist
//
//  Created by Hessah Saad on 20/05/1440 AH.
//  Copyright © 1440 Hessah Saad. All rights reserved.
//

import Foundation
import CoreData

extension Photo {
    public override func awakeFromInsert() {
        super.awakeFromInsert()
        creationDate = Date()
    }
}
