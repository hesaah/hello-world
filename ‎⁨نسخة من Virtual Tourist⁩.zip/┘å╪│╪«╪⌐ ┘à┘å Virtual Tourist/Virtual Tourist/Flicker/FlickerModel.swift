//
//  File.swift
//  Virtual Tourist
//
//  Created by Hessah Saad on 20/05/1440 AH.
//  Copyright © 1440 Hessah Saad. All rights reserved.
//

import Foundation

struct FlikerResbonse : Codable {
    let photos : Photos
    let stat : String
    
}

struct Photos : Codable {
    let perpage : Int
    let photo : [PhotoParse]
    
}

struct PhotoParse : Codable {
    let id : String
    let url_m : String
    
}


